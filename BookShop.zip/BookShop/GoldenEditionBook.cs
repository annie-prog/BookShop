﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace BookShop
{
    public class GoldenEditionBook : Book
    {
        public GoldenEditionBook(string author, string title, decimal price): base(author, title, 13/10*price)
        {
            
        }
       

    }
}

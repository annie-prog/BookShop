﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookShop
{
   public class Book
    {
        private string author;
        public string Author
        {
            get { return this.author; }
            set
            {
                if (value.Contains("'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'"))
                {
                    throw new ArgumentException("Author not valid!");
                }
                this.author = value;
            }
        }
        private string title;
        public string Title
        {
            get { return this.title; }
            set
            {
                if (value.Length < 3)
                {
                    throw new ArgumentException("Title not valid!");
                }
                this.title = value;
            }
        }
        private decimal price;

        public Book(string author, string title, decimal price)
        {
            this.author = author;
            this.title = title;
            this.price = price;
        }

        public decimal Price
        {
            get { return this.price; }
            set
            {
                if (value <=0)
                {
                    throw new ArgumentException("Price not valid!");
                }
                this.price = value;
            }
        }
        public override string ToString()
        {
            string result = $"Type: {this.GetType().Name}\n" + $"Title: {this.Title}\n" + $"Author: {this.Author}\n" + $"Price: {this.Price:f2}";
            return result;
        }


    }
}
